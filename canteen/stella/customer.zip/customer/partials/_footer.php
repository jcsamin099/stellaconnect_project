<footer class="py-5 opacity-8" style="background-color:#800000;color:#FFC000;">
  <div class="container">
    <div class="row align-items-center justify-content-xl-between">
      <div class="col-xl-6">
        <div class="copyright text-center text-xl-left ">
          &copy; <?php echo date('Y'); ?> - Developed By Stella Group
        </div>
      </div>
      <div class="col-xl-6">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
          <li class="nav-item">
            <a href="" class="nav-link" style="color:#FFC000;" target="_blank">Stella Canteen Management System</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>